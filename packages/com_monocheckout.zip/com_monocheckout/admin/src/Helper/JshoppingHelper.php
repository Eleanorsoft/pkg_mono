<?php

namespace Monobank\Component\MonoCheckout\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Jshopping\Site\Helper\SelectOptions;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;
use Joomla\Component\Jshopping\Site\Model\CartModel;
use Joomla\Component\Jshopping\Site\Model\OrderChangeStatusModel;
use Joomla\Component\Jshopping\Site\Table\OrderTable;

class JshoppingHelper {

    static $orderStatuses = null;

    public static function prepareOrderNumberForMono($orderNumber)
    {
        return MonoHelper::getOrderPrefix() . '-' . $orderNumber;
    }

    public static function parseOrderNumberFromMono($orderNumber)
    {
        $tmp = explode('-', $orderNumber);
        return end($tmp);
    }
    
    public static function getOrderByMonoData($data) {
        $order = JSFactory::getTable('order');
        $orderNumber = self::parseOrderNumberFromMono($data['basket_id']);
        $order->load(['order_number' => $orderNumber]);
        return $order;
    }

    public static function getCountryIdByMonoData($data)
    {
        $order = JSFactory::getTable('country');
        $order->load(['country_code_2' => 'UA']);
        return $order ? $order->getId() : 0;
    }

    public static function sanitizeValueForAdmin($val)
    {
        return htmlspecialchars($val);
    }

    public static function updateOrderFromMonoData($data)
    {
        Factory::getApplication()->bootComponent('com_jshopping');
        $order = self::getOrderByMonoData($data);
        $input = ['order_id' => $order->getId()];

        $input['f_name'] = self::sanitizeValueForAdmin(@$data['mainClientInfo']['first_name']);
        $input['l_name'] = self::sanitizeValueForAdmin(@$data['mainClientInfo']['last_name']);
        $input['email'] = self::sanitizeValueForAdmin(@$data['mainClientInfo']['email']);
        $input['phone'] = self::sanitizeValueForAdmin(@$data['mainClientInfo']['phone']);
        $input['country'] = self::getCountryIdByMonoData($data);

        $input['d_f_name'] = self::sanitizeValueForAdmin(@$data['deliveryRecipientInfo']['first_name']);
        $input['d_l_name'] = self::sanitizeValueForAdmin(@$data['deliveryRecipientInfo']['last_name']);
        $input['d_phone'] = self::sanitizeValueForAdmin(@$data['deliveryRecipientInfo']['phone']);
        $input['d_city'] = self::sanitizeValueForAdmin(@$data['deliveryAddressInfo']['cityName']);
        $input['d_state'] = self::sanitizeValueForAdmin(@$data['deliveryAddressInfo']['areaName']);
        if (@$data['delivery_branch_address']) {
            $input['d_street'] = self::sanitizeValueForAdmin(@$data['delivery_branch_address']);
        }
        if (@$data['delivery_branch_id']) {
            $input['d_street_nr'] = self::sanitizeValueForAdmin(@$data['delivery_branch_id']);
        }
        $input['d_country'] = self::getCountryIdByMonoData($data);

        $input['order_add_info'] = htmlspecialchars($data['comment']);

        switch ($data['generalStatus']) {
        case 'in_process':
        case 'payment_on_delivery':
        case 'success':
        case 'fail':
            if (!$order->payment_method_id) {
                switch ($data['payment_method']) {
                case 'payment_on_delivery':
                    $input['payment_method_id'] = MonoHelper::getConfig()->get(
                        'jshoppingpayment_cod_id'
                    );
                    break;
                default:
                    $input['payment_method_id'] = MonoHelper::getConfig()->get(
                        'jshoppingpayment_mono_id'
                    );
                    break;
                }
            }

            if (!$order->shipping_method_id) {
                switch ($data['delivery_method']) {
                case 'courier':
                    $input['shipping_method_id'] = MonoHelper::getConfig()->get(
                        'jshoppingshipping_courier_id'
                    );
                    break;
                case 'pickup':
                    $input['shipping_method_id'] = MonoHelper::getConfig()->get(
                        'jshoppingshipping_pickup_id'
                    );
                    break;
                default:
                    $input['shipping_method_id'] = MonoHelper::getConfig()->get(
                        'jshoppingshipping_np_id'
                    );
                    break;
                }
            }
        }

        foreach ($input as $k => $v) {
            $order->{$k} = $v;
        }
        $order->store();
//        $model = JSFactory::getModel("orders");
//        $post = $input;
//        $order = $model->save($post);

        if (!$order) {
            $errors = $order->getErrors();
            throw new \Exception($errors ? reset($errors) : "Can't store information in DB");
        }

        $targetStatus = 2;
        switch ($data['generalStatus']) {
        case 'not_authorized':
            $targetStatus = self::getNotAuthorizedStatusId();
            break;
        case 'not_confirmed':
            $targetStatus = self::getNotConfirmedStatusId();
            break;
        case 'in_process':
            $targetStatus = self::getPendingStatusId();
            break;

        case 'payment_on_delivery':
            $targetStatus = self::getPaymentOnDeliveryStatusId();
            break;
        case 'success':
            $targetStatus = self::getPaidStatusId();
            break;
        case 'fail':
            $targetStatus = self::getFailedStatusId();
            break;
        }

        if ($order->order_status != $targetStatus) {
            /** @var OrderChangeStatusModel $model */
            $model = JSFactory::getModel('orderChangeStatus', 'Site');
            $model->setData($order->getId(), $targetStatus, 0, $targetStatus, 0, json_encode($data));
            $model->store();
        }

        return $order;
    }

    public static function prepareMonoDataFromCart(CartModel $cart)
    {
        $adv_user = JSFactory::getUser();
        $checkout = JSFactory::getModel('checkoutOrder', 'Site');
        $checkout->setCart($cart);
        $post = [];
        $order = $checkout->orderDataSave($adv_user, $post);

        $data = json_decode('{
"order_ref":"' . JshoppingHelper::prepareOrderNumberForMono($order->order_number) . '",
"amount":320,
"products":[

],
"count":1,
"payments_number":3
}
', true);
        $data['products'] = [];
        $q = 0;
        $subtotal = 0;
        $hasShipping = false;
        foreach ($cart->products as $product) {
            $data['products'][] = [
                'code_product' => $product['product_id'],
                'name' => $product['product_name'],
                'cnt' => $product['quantity'],
                'price' => $product['price'],
            ];
            $files = false;
            if ($product['files']) {
                $f = unserialize($product['files']);
                if ($f) {
                    $files = true;
                }
            }
            if (!$files) {
                $hasShipping = true;
            }
            $q+= $product['quantity'];
            $subtotal+= $product['quantity'] * $product['price'];
        }
        $data['amount'] = $subtotal;
        $delivery_methods = MonoHelper::getDeliveryMethods();
        $payment_methods = MonoHelper::getPaymentMethods();
        $free_delivery_from = MonoHelper::getFreeDeliveryFrom();
        $payments_number = MonoHelper::getPaymentsNumber();
        if ($delivery_methods) { $data['dlv_method_list'] = $delivery_methods; }
        if (!$free_delivery_from and $free_delivery_from !== '0') { $data['dlv_pay_merchant'] = 0; }
        elseif ($subtotal > $free_delivery_from) { $data['dlv_pay_merchant'] = 1; }
        else { $data['dlv_pay_merchant'] = 0; }
        if ($payment_methods) { $data['payment_method_list'] = $payment_methods; }
        if ($payments_number) { $data['payments_number'] = $payments_number; }

        if (!$hasShipping) {
            if (!@$data['payment_method_list']) {
                $data['payment_method_list'] = array_keys(MonoHelper::getAllPaymentMethods());
            }
            $data['payment_method_list'] = array_values(array_filter(
                $data['payment_method_list'],
                function ($p) { return $p != 'payment_on_delivery'; }
            ));
        }

        $data['count'] = $q;
        $data['return_url'] = Route::_("index.php?option=com_monocheckout&task=checkout.finish", true, Route::TLS_IGNORE, true);
        $data['callback_url'] = Route::_("index.php?option=com_monocheckout&task=callback.process", true, Route::TLS_IGNORE, true);
        return [$data, $order];
    }

    public static function createOrderFromCart(CartModel $cart)
    {
        $app = \JFactory::getApplication();
        list($data, $order) = JshoppingHelper::prepareMonoDataFromCart($cart);
        $api = MonoHelper::getApi();
        $result = $api->create_order($data);
        $resultRaw = $api->last_raw_response;

        if (!$result or !@$result['redirect_url']) {
            $errorDescription = MonoHelper::getErrorText($api->last_error);
            /** @var OrderChangeStatusModel $model */
            $model = JSFactory::getModel('orderChangeStatus', 'Site');
            $model->setData($order->getId(), self::getFailedStatusId(), 0, self::getFailedStatusId(), 0, $api->last_raw_response);
            $model->store();

            throw new \Exception(sprintf(Text::_( 'COM_MONOCHECKOUT_ERROR_PNMT_ERROR' ), $errorDescription));
        }

        $order->order_created = 1;
        $order->store();
        $order->updateProductsInStock(1);
        $dispatcher = Factory::getApplication();
        $jshopConfig = JSFactory::getConfig();
        $dispatcher->triggerEvent('onAdminSaveOrderCreated', array(&$order));
        $checkout = JSFactory::getModel('checkout', 'Site');
        if ($jshopConfig->send_order_email){
            $checkout->sendOrderEmail($order->getId(), 1);
        }

        /** @var OrderChangeStatusModel $model */
        $model = JSFactory::getModel('orderChangeStatus', 'Site');
        $model->setData($order->getId(), self::getNotAuthorizedStatusId(), 0, self::getNotAuthorizedStatusId(), 0, $api->last_raw_response);
        $model->store();

        $redirect = @$result['redirect_url'];
        $cart->clear();
        $app->redirect($redirect);
        return true;
    }

    public static function fetchOrderDataFromMono($orderNumber)
    {
        $api = MonoHelper::getApi();
        $data = $api->update_order(self::prepareOrderNumberForMono($orderNumber));
        if ($data) {
            return self::updateOrderFromMonoData($data);
        }
        throw new \Exception(MonoHelper::getErrorText($api->last_error));
    }

    public static function loadOrderStatuses()
    {
        if (is_null(self::$orderStatuses)) {
            $statuses = SelectOptions::getOrderStatus();
            foreach ($statuses as $status) {
                self::$orderStatuses[$status->status_code] = $status->status_id;
            }
        }
    }

    public static function getNotAuthorizedStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['A'];
    }

    public static function getNotConfirmedStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['N'];
    }

    public static function getPaymentOnDeliveryStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['D'];
    }

    public static function getFailedStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['B'];
    }

    public static function getCompleteStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['F'];
    }

    public static function getPaidStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['O'];
    }

    public static function getPendingStatusId()
    {
        self::loadOrderStatuses();
        return self::$orderStatuses['P'];
    }

    public static function isMonoOrder(OrderTable $order)
    {
        if (!$order->history) { $order->history = $order->getHistory(); }
        if (count($order->history) > 1) {
            if ($order->history[1]->status_code == 'A') {
                $data = json_decode($order->history[1]->comments, true);
                if (MonoHelper::isMonoCallback($data)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function isOrderInFinalState(OrderTable $order)
    {
        if (!$order->history) { $order->history = $order->getHistory(); }
        for ($i = count($order->history) - 1; $i >= 0; $i--) {
            $data = json_decode($order->history[$i]->comments, true);
            if (MonoHelper::isMonoCallback($data)) {
                return MonoHelper::isOrderInFinalState($data);
            }
        }
        return false;
    }
    
}