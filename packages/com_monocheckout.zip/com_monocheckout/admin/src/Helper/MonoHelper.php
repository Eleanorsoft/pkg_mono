<?php

namespace Monobank\Component\MonoCheckout\Administrator\Helper;
defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;
use Monobank\Component\MonoCheckout\Administrator\Lib\MonoApi;

class MonoHelper {

    const COM = 'com_monocheckout';

    /**
     * @var Registry|null
     */
    static $config = null;

    public static function getApi() {
        static $api;
        if (!$api) {
            $url       = self::getConfig()->get('base_url');
            $token     = self::getConfig()->get('token');
            $file = __DIR__ . '/pub_key';
            $pub_key   = file_get_contents($file);
            if (!$pub_key or filemtime($file) < time() - 86400 * 1) {
                $pub_key = MonoApi::fetch_pub_key( $token, $url );
                if ($pub_key) {
                    @file_put_contents($file, $pub_key);
                }
            }
            $api = new MonoApi( $token, $url, $pub_key );
        }
        return $api;
    }

    public static function getErrorText($errorDescription)
    {
        $errorDescription = $errorDescription ?: Text::_('COM_MONOCHECKOUT_ERROR_TECHNICAL');
        if ($errorDescription == "Missing required header 'X-Token'") {
            $errorDescription = Text::_( 'COM_MONOCHECKOUT_ERROR_TOKEN_REQUIRED' );
        } elseif ($errorDescription == "forbidden") {
            $errorDescription = Text::_( 'COM_MONOCHECKOUT_ERROR_TOKEN_WRONG' );
        } elseif (stripos($errorDescription, "[payment_method_list]: ") !== false) {
            $tmp = explode(': ', $errorDescription);
            $methodCode = end($tmp);
            $paymentOptions = MonoHelper::getAllPaymentMethods();
            $methodName = (@$paymentOptions[$methodCode] ?: $methodCode);
            $errorDescription = sprintf(Text::_( 'COM_MONOCHECKOUT_ERROR_PNMT_METHOD_NOT_AVAILABLE' ), htmlspecialchars($methodName));
        } elseif (stripos($errorDescription, "[dlv_method_list]: ") !== false) {
            $tmp = explode(': ', $errorDescription);
            $methodCode = end($tmp);
            $shippingOptions = MonoHelper::getAllShippingMethods();
            $methodName = (@$shippingOptions[$methodCode] ?: $methodCode);
            $errorDescription = sprintf(Text::_( 'COM_MONOCHECKOUT_ERROR_DELIVERY_METHOD_NOT_AVAILABLE' ), htmlspecialchars($methodName));
        } elseif (stripos($errorDescription, "BLOCKED") !== false) {
            $errorDescription = Text::_( 'COM_MONOCHECKOUT_ERROR_CHECKOUT_DISABLED' );
        }
        return $errorDescription;
    }

    /**
     * @return Registry|null
     * @throws \Exception
     */
    public static function getConfig()
    {
        if (is_null(self::$config)) {
            self::$config = ComponentHelper::getParams(self::COM);
        }
        return self::$config;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public static function isEnabled()
    {
        return !!(int)self::getConfig()->get('enabled');
    }

    public static function showOnProductDetails()
    {
        return (self::isEnabled() && (int)self::getConfig()->get('enabled_details'));
    }

    public static function showInCart()
    {
        return (self::isEnabled() && (int)self::getConfig()->get('enabled_cart'));
    }

    public static function getOrderPrefix()
    {
        return (self::getConfig()->get('order_prefix') ?: self::getDefaultOrderPrefix());
    }

    public static function getDefaultOrderPrefix()
    {
        $domain = parse_url(Uri::root(), PHP_URL_HOST);
        $prefix = substr($domain, 0, 3);
        if (!$prefix) {
            $prefix = substr(md5(time()), 0 , 3);
        }
        if (strlen($prefix) < 3) {
            $prefix = substr($prefix . $prefix . $prefix, 0, 3);
        }
        return strtoupper($prefix);
    }

    public static function getButtonSizeOnDetails()
    {
        $config = self::getConfig();
        return [
            (int)$config['btn_details_width'],
            (int)$config['btn_details_height'],
        ];
    }

    public static function getButtonSizeInCart()
    {
        $config = self::getConfig();
        return [
            (int)$config['btn_cart_width'],
            (int)$config['btn_cart_height'],
        ];
    }

    public static function getButtonUrl()
    {
        $config = self::getConfig();
        $urls = [
            'black_normal' => Uri::root() . '/components/com_monocheckout/images/monocheckout_button_black_normal.svg',
            'black_short' => Uri::root() . '/components/com_monocheckout/images/monocheckout_button_black_short.svg',
            'white_normal' => Uri::root() . '/components/com_monocheckout/images/monocheckout_button_white_normal.svg',
            'white_short' => Uri::root() . '/components/com_monocheckout/images/monocheckout_button_white_short.svg',
        ];
        return $urls[$config['button']] ?? $urls['black_normal'];
    }

    public static function getDeliveryMethods()
    {
        $delivery_methods = MonoHelper::getConfig()->get('delivery_methods');
        return $delivery_methods ?: [];
    }

    public static function getPaymentMethods()
    {
        $methods = MonoHelper::getConfig()->get('payment_methods');
        return $methods ?: [];
    }

    public static function getFreeDeliveryFrom()
    {
        return (float)MonoHelper::getConfig()->get('free_delivery_from');
    }

    public static function getPaymentsNumber()
    {
        return (int)MonoHelper::getConfig()->get('payments_number');
    }

    public static function getAllPaymentMethods()
    {
        return [
            'card' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_PMNT_METHOD_CARD"),
            'payment_on_delivery' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_PMNT_METHOD_COD"),
            'part_purchase' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_PMNT_METHOD_PARTS"),
        ];
    }

    public static function getAllShippingMethods()
    {
        return [
            'pickup' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_DELIVERY_METHOD_PICKUP"),
            'courier' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_DELIVERY_METHOD_COURIER"),
            'np_brnm' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_DELIVERY_METHOD_NP_BRNM"),
            'np_box' => Text::_("COM_MONOCHECKOUT_CONFIG_GENERAL_DELIVERY_METHOD_NP_BOX"),
        ];
    }

    public static function isMonoCallback($data)
    {
        if (is_string($data)) {
            $data = json_decode($data, true);
        }
        if ($data and (isset($data['result']['order_id']) or isset($data['basket_id']))) {
            return true;
        }
        return false;
    }

    public static function isOrderInFinalState($data)
    {
        return $data['order_state'] == 11;
    }
}