<?php

namespace Monobank\Component\MonoCheckout\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;
use Monobank\Component\MonoCheckout\Administrator\Helper\JshoppingHelper;

class OrderController extends BaseController {

    public function update(){
        $app = Factory::getApplication();
        $app->bootComponent('com_jshopping');
        $order = JSFactory::getTable('order');
        $order->load($this->input->get('order_id'));
        if (JshoppingHelper::isMonoOrder($order) and !JshoppingHelper::isOrderInFinalState($order)) {
            try {
                JshoppingHelper::fetchOrderDataFromMono(
                    $this->input->get('order_id')
                );
                $app->enqueueMessage(Text::_('COM_MONOCHECKOUT_DATA_UPDATED'), 'success');
            } catch (\Exception $e) {
                $app->enqueueMessage($e->getMessage(), 'error');
                $this->setRedirect($_SERVER['HTTP_REFERER']);
                return $this->redirect();
            }
        }
        $this->setRedirect(Route::_('/administrator/index.php?option=com_jshopping&controller=orders&task=show&order_id=' . $this->input->get('order_id')));
    }
}