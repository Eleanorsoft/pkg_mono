<?php

namespace Monobank\Component\MonoCheckout\Administrator\Field;
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Component\Jshopping\Administrator\Model\PaymentsModel;
use Joomla\Component\Jshopping\Administrator\Model\ShippingsModel;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;

class JshoppingpaymentField extends ListField
{
	protected $type = 'jshoppingpayment';

	protected function getOptions(): array
	{
		$options = [];
        Factory::getApplication()->bootComponent('com_jshopping');
        /** @var PaymentsModel $model */
        $model = JSFactory::getModel('PaymentsModel');
        foreach ($model->getAllPaymentMethods() as $payment) {
            $options[] = HTMLHelper::_('select.option', $payment->payment_id, $payment->name);
        }

		return $options;
	}
}