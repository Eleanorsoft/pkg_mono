<?php

namespace Monobank\Component\MonoCheckout\Administrator\Field;
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Component\Jshopping\Administrator\Model\ShippingsModel;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;

class JshoppingshippingField extends ListField
{
	protected $type = 'jshoppingshipping';

	protected function getOptions(): array
	{
		$options = [];
        Factory::getApplication()->bootComponent('com_jshopping');
        /** @var ShippingsModel $model */
        $model = JSFactory::getModel('ShippingsModel');
        foreach ($model->getAllShippings() as $shipping) {
            $options[] = HTMLHelper::_('select.option', $shipping->shipping_id, $shipping->name);
        }

		return $options;
	}
}