<?php

namespace Monobank\Component\MonoCheckout\Administrator\View\Settings;

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;

class HtmlView extends BaseHtmlView {

    public $option_url;

    function display($tpl = null) {
        ToolBarHelper::title(Text::_('COM_MONOCHECKOUT_SETTINGS_TITLE'), 'generic.png' );
        ToolBarHelper::preferences('com_monocheckout');

        $uri    = (string) Uri::getInstance();
        $return = urlencode(base64_encode($uri));
        $this->option_url = Route::_('index.php?option=com_config&view=component&component=com_monocheckout&path=&return=' . $return);

        parent::display($tpl);
    }

}