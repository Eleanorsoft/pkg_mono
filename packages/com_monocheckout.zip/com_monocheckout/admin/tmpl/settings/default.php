<?php

use Joomla\CMS\Language\Text;

 // No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<style>
    .jshop_edit dd {
        margin-left:30px!important;
        margin-bottom:20px;
    }
</style>
<div id="j-main-container" class="j-main-container">
    <div class="jshop_edit">
        <h2>mono checkout</h2>
        <p>Щоб отримати токен, будь-ласка, скористайтесь Вашим додатком monobank, а потім перейдіть на <a href="https://web.monobank.ua/" target="_blank">web.monobank.ua</a></p>
        <p>Більше деталей на <a href="https://monobank.ua/" target="_blank">monobank.ua</a></p>
        <p><strong>Важливо:</strong> mono чекаут не підтримує замовлення з купонами.</p>
        <p><button onclick="location.href='<?php print $this->option_url; ?>';"><?php print Text::_('COM_MONOCHECKOUT_SETTINGS_BTN_LABEL'); ?></button></p>
        <hr/>
        <div>
            <h2>Статуси замовлень mono checkout:</h2>
            <dl class="status-list">
                <dt>Не авторизоване</dt>
                <dd>Користувач не пройшов авторизацію при вході в чекаут. Товар не відправляємо.</dd>
                <dt>Не підтверджене</dt>
                <dd>Користувач авторизувався в чекауті але не підтвердив покупку. Товар не відправляємо.</dd>
                <dt>Очікування оплати</dt>
                <dd>Користувач підтвердив оплату та перейшов на екран еквайрингу для підтвердження платежу. Підтвердження в процесі. Необхідно оновити статус трохи пізніше. Товар не відправляємо.</dd>
                <dt>Оплата при отриманні</dt>
                <dd>Користувач вибрав оплату при отриманні та підтвердив покупку. Можна відправляти товар.</dd>
                <dt>В обробці</dt>
                <dd>Користувач вибрав оплату карткою або ПЧ та підтвердив покупку. Користувач здійснив оплату успішно. Можна відправляти товар.</dd>
                <dt>Не вдалося</dt>
                <dd>Користувач підтвердив покупку але при платежі виникла помилка. Товар не відправляємо. Просимо користувача повторити оплату.</dd>
            </dl>
        </div>

        <hr>
        <div id="faq" style="visibility: visible;">

            <a name="faq"></a>
            <h2>Часті помилки</h2>
            <dl class="status-list">
                <dt>Будь-ласка, заповніть Токен чекауту для Вашого магазину.</dt>
                <dd>Ви можете отримати Токен чекауту на сайті <a href="https://web.monobank.ua" target="_blank">web.monobank.ua</a></dd>
                <dt>Будь-ласка, перевірте Токен чекауту для Вашого магазину.</dt>
                <dd>Будь-ласка, перевірте, що використовуєте правильно Токен чекауту з сайту <a href="https://web.monobank.ua" target="_blank">web.monobank.ua</a></dd>
                <dt>Платіжний метод X недоступний для Вашого магазину.</dt>
                <dd>Будь-ласка, зверніться до підтримки на сайті <a href="https://web.monobank.ua" target="_blank">web.monobank.ua</a>, щоб активувати відповідний платіжний метод для Вашого аккаунту. Тим часом Ви можете відключити цю опцію в налаштуваннях чекауту.</dd>
                <dt>Спосіб доставки X недоступний для Вашого магазину.</dt>
                <dd>Будь-ласка, зверніться до підтримки на сайті <a href="https://web.monobank.ua" target="_blank">web.monobank.ua</a>, щоб активувати відповідний спосіб доставки для Вашого аккаунту. Тим часом Ви можете відключити цю опцію в налаштуваннях чекауту.</dd>
                <dt>Чекаут відключений у Вашому аккаунті.</dt>
                <dd>Будь-ласка, ввімкніть чекаут у Вашому аккаунті на <a href="https://web.monobank.ua" target="_blank">web.monobank.ua</a></dd>
            </dl>
        </div>
    </div>
</div>