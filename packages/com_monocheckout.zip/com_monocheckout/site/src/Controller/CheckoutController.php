<?php

namespace Monobank\Component\MonoCheckout\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\Component\Jshopping\Site\Helper\Metadata;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;
use Monobank\Component\MonoCheckout\Administrator\Helper\JshoppingHelper;
use Joomla\Component\Jshopping\Site\Helper\Helper;

class CheckoutController extends BaseController {

    public function cart()
    {
        $app = Factory::getApplication();

        $app->bootComponent('com_jshopping');
        $cart = JSFactory::getModel('cart', 'Site');
        $cart->load();
        try {
            JshoppingHelper::createOrderFromCart($cart);
        } catch (\Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
            $this->setRedirect($_SERVER['HTTP_REFERER']);
            return $this->redirect();
        }
    }

    public function finish()
    {
        $app = Factory::getApplication();

        $app->bootComponent('com_jshopping');
        $checkout = JSFactory::getModel('checkoutFinish', 'Site');
        $text = $checkout->getFinishStaticText();
        $text_end = '';
        $document = $app->getDocument();
        $document->setTitle(Text::_('mono checkout'));
        Helper::appendPathWay(Text::_('mono checkout'));

        /** @var \Joomla\CMS\MVC\View\HtmlView $view */
        $view = $this->getView('checkout', 'html');
        $view->set('text', $text);
        $view->set('text_end', $text_end);
        $view->display();
    }
    
}