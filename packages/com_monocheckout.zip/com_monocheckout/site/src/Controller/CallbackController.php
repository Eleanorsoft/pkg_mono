<?php

namespace Monobank\Component\MonoCheckout\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Monobank\Component\MonoCheckout\Administrator\Helper\JshoppingHelper;
use Monobank\Component\MonoCheckout\Administrator\Helper\MonoHelper;

class CallbackController extends BaseController {
    
    public function process($cachable = false, $urlparams = array()) {        
        $input = Factory::getApplication()->input;
        if (!MonoHelper::getApi()->validate_webhook( @$_SERVER['HTTP_X_SIGN'], $input->json->getRaw() )) { // incorrect signature
            http_response_code(400);
            die(400);
        }
        JshoppingHelper::updateOrderFromMonoData($input->json->getArray());
        exit;
    }
    
}