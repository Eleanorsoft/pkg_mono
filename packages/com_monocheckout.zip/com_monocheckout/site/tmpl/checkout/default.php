<?php
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;
?>
<?php if (!empty($this->text)){?>
    <?php echo $this->text;?>
<?php }else{?>
    <p><?php print Text::_('COM_MONOCHECKOUT_THANK_YOU_ORDER')?></p>
<?php }?>
<?php echo $this->text_end;?>