<?php
use Joomla\CMS\Factory;
use Joomla\Component\Jshopping\Site\Helper\SelectOptions;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;

defined('_JEXEC') or die();

class com_monocheckoutInstallerScript {
    public function update(){
        Factory::getApplication()->bootComponent('com_jshopping');
        $statuses = SelectOptions::getOrderStatus();
        $existing = array_map(function ($s) { return $s->status_code; }, $statuses);
        $model = JSFactory::getModel('OrderstatusModel');
        if (!in_array('A', $existing)) {
            $model->save(['status_code' => 'A', 'name_en-GB' => 'Not Authorized']);
        }
        if (!in_array('N', $existing)) {
            $model->save(['status_code' => 'N', 'name_en-GB' => 'Not Confirmed']);
        }
        if (!in_array('D', $existing)) {
            $model->save(['status_code' => 'D', 'name_en-GB' => 'Payment on Delivery']);
        }
        if (!in_array('B', $existing)) {
            $model->save(['status_code' => 'B', 'name_en-GB' => 'Failed']);
        }
    }
}