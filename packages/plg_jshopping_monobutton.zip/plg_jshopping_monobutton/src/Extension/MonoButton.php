<?php

namespace Monobank\Plugin\Jshopping\MonoButton\Extension;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareTrait;
use Monobank\Component\MonoCheckout\Administrator\Helper\MonoHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects


final class MonoButton extends CMSPlugin
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    protected $autoloadLanguage = true;

    public function onBeforeDisplayProductView($view)
    {
        if (MonoHelper::showOnProductDetails()) {
            $phrase = Text::_('PLG_JSHOPPING_MONOBUTTON_BUY_WITH_MONO');
            $loadingText = Text::_('PLG_JSHOPPING_MONOBUTTON_LOADING');
            $imgStyle = '';
            $attrStr = '';
            list($mono_btn_width, $mono_btn_height) = MonoHelper::getButtonSizeOnDetails();
            $mono_btn_url = MonoHelper::getButtonUrl();
            if ($mono_btn_width > 0) {
                $imgStyle.= 'width:' . intval($mono_btn_width) . 'px !important;';
                $attrStr.= ' width="' . intval($mono_btn_width) . '" ';
            }
            if ($mono_btn_height > 0) {
                $imgStyle.= 'height:' . intval($mono_btn_height) . 'px !important;';
                $attrStr.= ' height="' . intval($mono_btn_height) . '" ';
            }
            ob_start();
            ?>
<div class="monocheckout-wrapper">
    <a href="#"
       data-loading-phrase="<?php print $loadingText; ?>"
       onclick="return clickMonoCheckoutButton()"
       >
        <?php if ($attrStr) { ?>
            <svg
                <?php if ($mono_btn_width > 0) { ?>
                    width="<?php print $mono_btn_width; ?>"
                <?php } ?>
                <?php if ($mono_btn_height > 0) { ?>
                    height="<?php print $mono_btn_height; ?>"
                <?php } ?>
            >
                <image preserveAspectRatio="none"
                       xlink:href="<?php print htmlspecialchars($mono_btn_url); ?>"
                    <?php if ($mono_btn_width > 0) { ?>
                        width="<?php print $mono_btn_width; ?>"
                    <?php } ?>
                    <?php if ($mono_btn_height > 0) { ?>
                        height="<?php print $mono_btn_height; ?>"
                    <?php } ?>
                />
            </svg>
        <?php } else { ?>
            <img src="<?php print htmlspecialchars($mono_btn_url); ?>"
                 style="<?php print ($imgStyle); ?>"
                 alt="<?php print htmlspecialchars($phrase); ?>" />
        <?php } ?></a>
    <input type="submit"
           class="btn button btn-wishlist btn-secondary"
           style="display:none;"
           id="monocheckout-button"
           value="<?php print htmlspecialchars($phrase); ?>" onclick="jQuery('#to').val('mono');">
</div>
            <script>
                let MONO_CHECKOUT_CLICKED = false;
                let MONO_CHECKOUT_TIMER = null;
                function clickMonoCheckoutButton() {
                  if (jQuery('.monocheckout-wrapper a').hasClass('loading')) {
                    return false;
                  }
                  MONO_CHECKOUT_CLICKED = true;
                  clearTimeout(MONO_CHECKOUT_TIMER);
                  setTimeout(function () { MONO_CHECKOUT_CLICKED = false; }, 2000);
                  jQuery('#monocheckout-button').click();
                  return false;
                }
                jQuery(function () {
                  if (document.product) {
                    document.product.addEventListener('submit', function () {
                      if (MONO_CHECKOUT_CLICKED) {
                        jQuery('.monocheckout-wrapper a').addClass('loading');
                      }
                    });
                  }
                });
            </script>
            <style>
                .monocheckout-wrapper {
                    margin:16px 0;
                }
                .monocheckout-wrapper a {
                    display:inline-block;
                    position:relative;
                    line-height:0;
                }
                .monocheckout-wrapper a.loading::before {
                    content: attr(data-loading-phrase);
                    top:0;
                    left:0;
                    position: absolute;
                    width:100%;
                    height:100%;
                    background:#000c;
                    text-align: center;
                    color:#fff;
                    padding:5px;
                    box-sizing: border-box;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 14px;
                    border-radius: 7px;
                }
            </style>
<?php
            $button = ob_get_clean();

            $view->_tmp_product_html_after_buttons .= $button;
        }
    }

}
