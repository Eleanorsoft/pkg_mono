<?php

namespace Monobank\Plugin\Jshoppingcheckout\MonoCheckout\Extension;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Component\Jshopping\Site\Lib\JSFactory;
use Joomla\Component\Jshopping\Site\Model\CartModel;
use Joomla\Database\DatabaseAwareTrait;
use Monobank\Component\MonoCheckout\Administrator\Helper\JshoppingHelper;
use Monobank\Component\MonoCheckout\Administrator\Helper\MonoHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

final class MonoCheckout extends CMSPlugin
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    public $autoloadLanguage = true;

    public function onAfterCartAddOk(CartModel $cart, $product_id, $quantity)
    {
        $app = Factory::getApplication();
        if ($cart->type_cart == 'mono') {
            try {
                JshoppingHelper::createOrderFromCart($cart);
            } catch (\Exception $e) {
                $app->enqueueMessage($e->getMessage(), 'error');
                return $app->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    public function onBeforeDisplayCartView(&$view)
    {
        if (MonoHelper::showInCart()) {
            /** @var CartModel $cart */
            $cart = JSFactory::getModel('cart', 'Site');
            $cart->load();
            if ($cart->rabatt_id) {
                return;
            }
            if (count($view->products)) {
                $phrase = Text::_('PLG_JSHOPPINGCHECKOUT_MONOCHECKOUT_BUY_WITH_MONO');
                $loadingText = Text::_('PLG_JSHOPPINGCHECKOUT_MONOCHECKOUT_LOADING');
                $imgStyle = '';
                $attrStr = '';
                list($mono_btn_width, $mono_btn_height) = MonoHelper::getButtonSizeInCart();
                $mono_btn_url = MonoHelper::getButtonUrl();
                if ($mono_btn_width > 0) {
                    $imgStyle.= 'width:' . intval($mono_btn_width) . 'px !important;';
                    $attrStr.= ' width="' . intval($mono_btn_width) . '" ';
                }
                if ($mono_btn_height > 0) {
                    $imgStyle.= 'height:' . intval($mono_btn_height) . 'px !important;';
                    $attrStr.= ' height="' . intval($mono_btn_height) . '" ';
                }
                $url = Route::_("index.php?option=com_monocheckout&task=checkout.cart");
                ob_start();
            ?>
            <div class="monocheckout-wrapper">
                <a href="<?php print $url; ?>"
                   onclick="return clickMonoCheckoutButton()"
                   data-loading-phrase="<?php print $loadingText; ?>"
                >
                    <?php if ($attrStr) { ?>
                        <svg
                            <?php if ($mono_btn_width > 0) { ?>
                                width="<?php print $mono_btn_width; ?>"
                            <?php } ?>
                            <?php if ($mono_btn_height > 0) { ?>
                                height="<?php print $mono_btn_height; ?>"
                            <?php } ?>
                        >
                            <image preserveAspectRatio="none"
                                   xlink:href="<?php print htmlspecialchars($mono_btn_url); ?>"
                                <?php if ($mono_btn_width > 0) { ?>
                                    width="<?php print $mono_btn_width; ?>"
                                <?php } ?>
                                <?php if ($mono_btn_height > 0) { ?>
                                    height="<?php print $mono_btn_height; ?>"
                                <?php } ?>
                            />
                        </svg>
                    <?php } else { ?>
                        <img src="<?php print htmlspecialchars($mono_btn_url); ?>"
                             style="<?php print ($imgStyle); ?>"
                             alt="<?php print htmlspecialchars($phrase); ?>" />
                    <?php } ?></a>
            </div>
                <script>
                  function clickMonoCheckoutButton() {
                    if (jQuery('.monocheckout-wrapper a').hasClass('loading')) {
                      return false;
                    }
                    jQuery('.monocheckout-wrapper a').addClass('loading');
                    return true;
                  }
                </script>
                <style>
                    .monocheckout-wrapper {
                        margin:16px 0;
                    }
                    .monocheckout-wrapper a {
                        display:inline-block;
                        position:relative;
                        line-height:0;
                    }
                    .monocheckout-wrapper a.loading::before {
                        content: attr(data-loading-phrase);
                        top:0;
                        left:0;
                        position: absolute;
                        width:100%;
                        height:100%;
                        background:#000c;
                        text-align: center;
                        color:#fff;
                        padding:5px;
                        box-sizing: border-box;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 14px;
                        border-radius: 7px;
                    }
                </style>
            <?php
                $button = ob_get_clean();

                $view->_tmp_html_after_buttons .= $button;
            }
        }
    }

}
