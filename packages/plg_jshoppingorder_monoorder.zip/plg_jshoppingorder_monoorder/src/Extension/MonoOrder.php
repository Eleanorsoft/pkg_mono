<?php

namespace Monobank\Plugin\Jshoppingorder\MonoOrder\Extension;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareTrait;
use Monobank\Component\MonoCheckout\Administrator\Helper\JshoppingHelper;
use Monobank\Component\MonoCheckout\Administrator\Helper\MonoHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

final class MonoOrder extends CMSPlugin
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    public $autoloadLanguage = true;

    public function onBeforeShowOrder($view)
    {
        $order = $view->get('order');
        if (JshoppingHelper::isMonoOrder($order)) {
            if (!JshoppingHelper::isOrderInFinalState($order)) {
                $bar = Toolbar::getInstance('toolbar');
                $bar->appendButton(
                    'Link',
                    'refresh',
                    Text::_('PLG_JSHOPPINGORDER_MONOORDER_UPDATE_ORDER_STATUS_FROM_MONO'),
                    Route::_(
                        '/administrator/index.php?option=com_monocheckout&task=order.update&order_id='
                        . urlencode($view->get('order')->order_number)
                    )
                );
            }
            $history = $view->get('order_history');
            $lastMonoCallback = null;
            foreach ($history as $entry) {
                $data = json_decode($entry->comments, true);
                if (MonoHelper::isMonoCallback($data)) {
                    $apiAnswer = $entry->comments;
                    $entry->comments = '';
                    if (@$data['result']['order_id']) {
                        $entry->comments.= Text::_('PLG_JSHOPPINGORDER_MONOORDER_MONO_ID') . ': ' . htmlspecialchars($data['result']['order_id']) . '<br/>';
                        $entry->comments.= '<a href="' . htmlspecialchars($data['result']['redirect_url']) . '" target="_blank">' . Text::_('PLG_JSHOPPINGORDER_MONOORDER_CHECKOUT_LINK') . '</a><br/>';
                    }
                    $entry->comments.= '<a href="javascript:void(0);" onclick="jQuery(this).next().toggle()">' . Text::_('PLG_JSHOPPINGORDER_MONOORDER_API_ANSWER') . '</a><pre style="display:none;white-space: pre-wrap"><code>' . htmlspecialchars($apiAnswer) . '</code></pre>';
                    $lastMonoCallback = $data;
                }
            }
            if ($lastMonoCallback) {
                $val = ($lastMonoCallback['clientCallback'] ? Text::_('PLG_JSHOPPINGORDER_MONOORDER_OPTION_YES') : Text::_('PLG_JSHOPPINGORDER_MONOORDER_OPTION_NO'));
                $label = Text::_('PLG_JSHOPPINGORDER_MONOORDER_CALLBACKCLIENT');
                $view->tmp_fields.=<<<FIELD
        <tr>
          <td><b>$label:</b></td>
          <td>$val</td>
        </tr>
FIELD;

                if (@$lastMonoCallback['deliveryAddressInfo']) {
                    $deliveryAddressInfo = @$lastMonoCallback['deliveryAddressInfo'];
                    if ($deliveryAddressInfo) {
                        $areaName = htmlspecialchars(@$deliveryAddressInfo['areaName']);
                        $areaRef = htmlspecialchars(@$deliveryAddressInfo['areaRef']);
                        $cityName = htmlspecialchars(@$deliveryAddressInfo['cityName']);
                        $cityRef = htmlspecialchars(@$deliveryAddressInfo['cityRef']);
                        $npRegionLabel = Text::_('PLG_JSHOPPINGORDER_MONOORDER_NP_REGION');
                        $npCityLabel = Text::_('PLG_JSHOPPINGORDER_MONOORDER_NP_CITY');
                        $copyCodeLabel = Text::_('PLG_JSHOPPINGORDER_MONOORDER_COPY_CODE');
                        $view->tmp_d_fields.=<<<FIELD
        <tr>
          <td><b>$npRegionLabel:</b></td>
          <td>$areaName (<a href="" onclick="try {navigator.clipboard.writeText('$areaRef');}catch(e){} return false;">$copyCodeLabel</a>)</td>
        </tr>
FIELD;
                        $view->tmp_d_fields.=<<<FIELD
        <tr>
          <td><b>$npCityLabel:</b></td>
          <td>$cityName (<a href="" onclick="try {navigator.clipboard.writeText('$cityRef');}catch(e){} return false;">$copyCodeLabel</a>)</td>
        </tr>
FIELD;
                    }
                }

                $descriptions = self::getStatusDescriptions();
                if (isset($descriptions[$order->status_name])) {
                    $view->tmp_html_info.=<<<FIELD
        <tr>
          <td colspan="2">{$descriptions[$order->status_name]}</td>
        </tr>
FIELD;
                }
            }
        }
    }

    public static function getStatusDescriptions()
    {
        return [
            'Not Authorized' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_NOT_AUTHORIZED'),
            'Not Confirmed' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_NOT_CONFIRMED'),
            'Confirmed' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_CONFIRMED'),
            'Payment on delivery' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_PAYMENT_ON_DELIVERY'),
            'Paid' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_PAID'),
            'Failed' => Text::_('PLG_JSHOPPINGORDER_MONOORDER_STATUS_DESC_FAILED'),
        ];
    }

    public function onBeforeDisplayOrderView($view)
    {
        $order = $view->get('order');
        if (JshoppingHelper::isMonoOrder($order)) {
            foreach ($order->history as $item) {
                if (MonoHelper::isMonoCallback($item->comments)) {
                    $item->comments = '';
                }
            }
        }
    }

}
